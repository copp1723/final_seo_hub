export { middleware, config } from './middleware/middleware-simple'
