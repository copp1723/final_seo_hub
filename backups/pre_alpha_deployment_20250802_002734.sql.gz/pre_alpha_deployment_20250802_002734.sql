--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg120+1)
-- Dumped by pg_dump version 16.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: rylie_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO rylie_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: rylie_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: PackageType; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."PackageType" AS ENUM (
    'SILVER',
    'GOLD',
    'PLATINUM'
);


ALTER TYPE public."PackageType" OWNER TO rylie_user;

--
-- Name: RequestPriority; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."RequestPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


ALTER TYPE public."RequestPriority" OWNER TO rylie_user;

--
-- Name: RequestStatus; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."RequestStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."RequestStatus" OWNER TO rylie_user;

--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."TaskStatus" OWNER TO rylie_user;

--
-- Name: TaskType; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."TaskType" AS ENUM (
    'PAGE',
    'BLOG',
    'GBP_POST',
    'IMPROVEMENT'
);


ALTER TYPE public."TaskType" OWNER TO rylie_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: rylie_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'USER',
    'ADMIN',
    'AGENCY_ADMIN',
    'SUPER_ADMIN',
    'DEALERSHIP_ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO rylie_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO rylie_user;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO rylie_user;

--
-- Name: agencies; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.agencies (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    "primaryColor" text DEFAULT '#3b82f6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1e40af'::text NOT NULL,
    logo text,
    plan text DEFAULT 'starter'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "maxConversations" integer DEFAULT 100 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "ga4PropertyId" text,
    "ga4PropertyName" text,
    "ga4RefreshToken" text
);


ALTER TABLE public.agencies OWNER TO rylie_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "userEmail" text NOT NULL,
    "userId" text,
    details jsonb,
    resource text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO rylie_user;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    title text NOT NULL,
    model text DEFAULT 'gpt-4-turbo'::text NOT NULL,
    "agencyId" text NOT NULL,
    "userId" text NOT NULL,
    "messageCount" integer DEFAULT 0 NOT NULL,
    "lastMessage" text,
    "lastMessageAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.conversations OWNER TO rylie_user;

--
-- Name: dealership_onboardings; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.dealership_onboardings (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "businessName" text NOT NULL,
    package text NOT NULL,
    "mainBrand" text NOT NULL,
    "otherBrand" text,
    address text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    "zipCode" text NOT NULL,
    "contactName" text NOT NULL,
    "contactTitle" text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    "websiteUrl" text NOT NULL,
    "billingEmail" text NOT NULL,
    "siteAccessNotes" text,
    "targetVehicleModels" text[],
    "targetCities" text[],
    "targetDealers" text[],
    "submittedBy" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "seoworksResponse" jsonb,
    "submittedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.dealership_onboardings OWNER TO rylie_user;

--
-- Name: dealerships; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.dealerships (
    id text NOT NULL,
    name text NOT NULL,
    "agencyId" text NOT NULL,
    website text,
    address text,
    phone text,
    "activePackageType" public."PackageType",
    "currentBillingPeriodStart" timestamp(3) without time zone,
    "currentBillingPeriodEnd" timestamp(3) without time zone,
    "pagesUsedThisPeriod" integer DEFAULT 0 NOT NULL,
    "blogsUsedThisPeriod" integer DEFAULT 0 NOT NULL,
    "gbpPostsUsedThisPeriod" integer DEFAULT 0 NOT NULL,
    "improvementsUsedThisPeriod" integer DEFAULT 0 NOT NULL,
    settings jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "clientId" text,
    "ga4PropertyId" text,
    "searchConsoleSiteUrl" text
);


ALTER TABLE public.dealerships OWNER TO rylie_user;

--
-- Name: COLUMN dealerships."ga4PropertyId"; Type: COMMENT; Schema: public; Owner: rylie_user
--

COMMENT ON COLUMN public.dealerships."ga4PropertyId" IS 'Google Analytics 4 property ID for this dealership';


--
-- Name: COLUMN dealerships."searchConsoleSiteUrl"; Type: COMMENT; Schema: public; Owner: rylie_user
--

COMMENT ON COLUMN public.dealerships."searchConsoleSiteUrl" IS 'Google Search Console site URL for this dealership';


--
-- Name: escalations; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.escalations (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "userId" text NOT NULL,
    "userEmail" text NOT NULL,
    "conversationId" text NOT NULL,
    subject text NOT NULL,
    description text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    category text,
    "chatContext" jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    "assignedTo" text,
    "assignedAt" timestamp(3) without time zone,
    resolution text,
    "resolvedBy" text,
    "resolvedAt" timestamp(3) without time zone,
    "internalNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.escalations OWNER TO rylie_user;

--
-- Name: feature_flag_overrides; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.feature_flag_overrides (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "flagKey" text NOT NULL,
    enabled boolean NOT NULL,
    "rolloutPercentage" integer DEFAULT 100 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.feature_flag_overrides OWNER TO rylie_user;

--
-- Name: ga4_connections; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.ga4_connections (
    id text NOT NULL,
    "userId" text NOT NULL,
    "dealershipId" text,
    "accessToken" text NOT NULL,
    "refreshToken" text,
    "expiresAt" timestamp(3) without time zone,
    "propertyId" text,
    "propertyName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.ga4_connections OWNER TO rylie_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.messages (
    id text NOT NULL,
    content text NOT NULL,
    role text NOT NULL,
    model text,
    "agencyId" text NOT NULL,
    "conversationId" text NOT NULL,
    "userId" text NOT NULL,
    "tokenCount" integer,
    "responseTime" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO rylie_user;

--
-- Name: monthly_usage; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.monthly_usage (
    id text NOT NULL,
    "userId" text,
    "dealershipId" text,
    month integer NOT NULL,
    year integer NOT NULL,
    "packageType" public."PackageType" NOT NULL,
    "pagesUsed" integer NOT NULL,
    "blogsUsed" integer NOT NULL,
    "gbpPostsUsed" integer NOT NULL,
    "improvementsUsed" integer NOT NULL,
    "archivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.monthly_usage OWNER TO rylie_user;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "agencyId" text,
    "userEmail" text NOT NULL,
    "taskType" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "assignedTo" text,
    "estimatedHours" double precision,
    "actualHours" double precision,
    deliverables jsonb,
    "completionNotes" text,
    "qualityScore" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "seoworksTaskId" text
);


ALTER TABLE public.orders OWNER TO rylie_user;

--
-- Name: orphaned_tasks; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.orphaned_tasks (
    id text NOT NULL,
    "clientId" text,
    "clientEmail" text,
    "taskType" text NOT NULL,
    "externalId" text NOT NULL,
    status text NOT NULL,
    "completionDate" timestamp(3) without time zone,
    deliverables jsonb DEFAULT '[]'::jsonb,
    "rawPayload" jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "eventType" text,
    "linkedRequestId" text,
    notes text
);


ALTER TABLE public.orphaned_tasks OWNER TO rylie_user;

--
-- Name: report_schedules; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.report_schedules (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "cronPattern" text NOT NULL,
    "ga4PropertyId" text NOT NULL,
    "userId" text NOT NULL,
    "reportType" text NOT NULL,
    "emailRecipients" text[],
    "brandingOptionsJson" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastRun" timestamp(3) without time zone,
    "nextRun" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.report_schedules OWNER TO rylie_user;

--
-- Name: requests; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.requests (
    id text NOT NULL,
    "userId" text NOT NULL,
    "agencyId" text,
    title text NOT NULL,
    description text NOT NULL,
    type text NOT NULL,
    priority public."RequestPriority" DEFAULT 'MEDIUM'::public."RequestPriority" NOT NULL,
    status public."RequestStatus" DEFAULT 'PENDING'::public."RequestStatus" NOT NULL,
    "packageType" public."PackageType",
    "pagesCompleted" integer DEFAULT 0 NOT NULL,
    "blogsCompleted" integer DEFAULT 0 NOT NULL,
    "gbpPostsCompleted" integer DEFAULT 0 NOT NULL,
    "improvementsCompleted" integer DEFAULT 0 NOT NULL,
    keywords jsonb,
    "targetUrl" text,
    "targetCities" jsonb,
    "targetModels" jsonb,
    "completedTasks" jsonb,
    "contentUrl" text,
    "pageTitle" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "dealershipId" text,
    "seoworksTaskId" text
);


ALTER TABLE public.requests OWNER TO rylie_user;

--
-- Name: search_console_connections; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.search_console_connections (
    id text NOT NULL,
    "userId" text NOT NULL,
    "dealershipId" text,
    "accessToken" text NOT NULL,
    "refreshToken" text,
    "expiresAt" timestamp(3) without time zone,
    "siteUrl" text,
    "siteName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.search_console_connections OWNER TO rylie_user;

--
-- Name: seoworks_task_mappings; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.seoworks_task_mappings (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "seoworksTaskId" text NOT NULL,
    "taskType" text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.seoworks_task_mappings OWNER TO rylie_user;

--
-- Name: seoworks_tasks; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.seoworks_tasks (
    id text NOT NULL,
    "externalId" text NOT NULL,
    "taskType" text NOT NULL,
    status text NOT NULL,
    "completionDate" timestamp(3) without time zone,
    "postTitle" text NOT NULL,
    "postUrl" text,
    "completionNotes" text,
    "isWeekly" boolean DEFAULT false NOT NULL,
    payload jsonb,
    "orderId" text,
    "agencyId" text,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processedAt" timestamp(3) without time zone
);


ALTER TABLE public.seoworks_tasks OWNER TO rylie_user;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO rylie_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.system_settings (
    id text DEFAULT 'default'::text NOT NULL,
    "maintenanceMode" boolean DEFAULT false NOT NULL,
    "newUserRegistration" boolean DEFAULT true NOT NULL,
    "emailNotifications" boolean DEFAULT true NOT NULL,
    "auditLogging" boolean DEFAULT true NOT NULL,
    "maxUsersPerAgency" integer DEFAULT 50 NOT NULL,
    "maxRequestsPerUser" integer DEFAULT 1000 NOT NULL,
    "maxFileUploadSize" integer DEFAULT 10 NOT NULL,
    "smtpHost" text DEFAULT ''::text NOT NULL,
    "smtpPort" integer DEFAULT 587 NOT NULL,
    "smtpUser" text DEFAULT ''::text NOT NULL,
    "smtpFromEmail" text DEFAULT ''::text NOT NULL,
    "maintenanceMessage" text DEFAULT 'The system is currently under maintenance. Please try again later.'::text NOT NULL,
    "welcomeMessage" text DEFAULT 'Welcome to our SEO management platform! Get started by exploring your dashboard.'::text NOT NULL,
    "rateLimitPerMinute" integer DEFAULT 60 NOT NULL,
    "sessionTimeoutMinutes" integer DEFAULT 480 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO rylie_user;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.tasks (
    id text NOT NULL,
    "userId" text NOT NULL,
    "dealershipId" text,
    "agencyId" text,
    type public."TaskType" NOT NULL,
    status public."TaskStatus" DEFAULT 'PENDING'::public."TaskStatus" NOT NULL,
    title text NOT NULL,
    description text,
    priority public."RequestPriority" DEFAULT 'MEDIUM'::public."RequestPriority" NOT NULL,
    "targetUrl" text,
    keywords jsonb,
    "requestId" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tasks OWNER TO rylie_user;

--
-- Name: themes; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.themes (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "companyName" text NOT NULL,
    "primaryColor" text NOT NULL,
    "secondaryColor" text NOT NULL,
    logo text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.themes OWNER TO rylie_user;

--
-- Name: usage_metrics; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.usage_metrics (
    id text NOT NULL,
    "agencyId" text NOT NULL,
    "metricType" text NOT NULL,
    value integer NOT NULL,
    model text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    period text DEFAULT 'daily'::text NOT NULL
);


ALTER TABLE public.usage_metrics OWNER TO rylie_user;

--
-- Name: user_ga4_tokens; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.user_ga4_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "encryptedAccessToken" text NOT NULL,
    "encryptedRefreshToken" text,
    "expiryDate" timestamp(3) without time zone,
    scope text,
    "tokenType" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_ga4_tokens OWNER TO rylie_user;

--
-- Name: user_invites; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.user_invites (
    id text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    "isSuperAdmin" boolean DEFAULT false NOT NULL,
    "agencyId" text,
    "invitedBy" text NOT NULL,
    token text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "acceptedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_invites OWNER TO rylie_user;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.user_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "emailNotifications" boolean DEFAULT true NOT NULL,
    "requestCreated" boolean DEFAULT true NOT NULL,
    "statusChanged" boolean DEFAULT true NOT NULL,
    "taskCompleted" boolean DEFAULT true NOT NULL,
    "weeklySummary" boolean DEFAULT true NOT NULL,
    "marketingEmails" boolean DEFAULT false NOT NULL,
    timezone text DEFAULT 'America/New_York'::text,
    language text DEFAULT 'en'::text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_preferences OWNER TO rylie_user;

--
-- Name: user_search_console_tokens; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.user_search_console_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "encryptedAccessToken" text NOT NULL,
    "encryptedRefreshToken" text,
    "expiryDate" timestamp(3) without time zone,
    scope text,
    "verifiedSites" text[],
    "primarySite" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_search_console_tokens OWNER TO rylie_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    "agencyId" text,
    "dealershipId" text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    theme text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isSuperAdmin" boolean DEFAULT false NOT NULL,
    "onboardingCompleted" boolean DEFAULT false NOT NULL,
    "invitationToken" text,
    "invitationTokenExpires" timestamp(3) without time zone,
    "apiKey" text,
    "apiKeyCreatedAt" timestamp(3) without time zone,
    password text
);


ALTER TABLE public.users OWNER TO rylie_user;

--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: rylie_user
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO rylie_user;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f431df30-5c61-4fb0-be2c-4119840ba98a	523a73f01b1dc85875ed27a1e6049c7545106622584b35d0c0f9e57614a29f5b	2025-07-20 17:14:32.780523+00	20250103_initial_schema	\N	\N	2025-07-20 17:14:32.046395+00	1
45c1f609-14e6-4203-bde6-7c582b5bffc6	4754198bbb3fc040bc54fe52fbe5b3e0f0bd0d91475de9b535dd8ebf9a76e1dc	\N	20250108_fix_seoworks_mapping	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250108_fix_seoworks_mapping\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "Request" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"Request\\" does not exist", detail: None, hint: None, position: None, where_: Some("SQL statement \\"ALTER TABLE \\"SEOWorksTaskMapping\\" ADD CONSTRAINT \\"SEOWorksTaskMapping_requestId_fkey\\" \\n        FOREIGN KEY (\\"requestId\\") REFERENCES \\"Request\\"(\\"id\\") ON DELETE CASCADE ON UPDATE CASCADE\\"\\nPL/pgSQL function inline_code_block line 8 at SQL statement"), schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250108_fix_seoworks_mapping"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250108_fix_seoworks_mapping"\n             at schema-engine/commands/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-07-25 21:21:59.36091+00	2025-07-20 17:14:33.019301+00	0
57f46141-45b5-46e5-9ef1-bc7b67c34a94	4754198bbb3fc040bc54fe52fbe5b3e0f0bd0d91475de9b535dd8ebf9a76e1dc	\N	20250108_fix_seoworks_mapping	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250108_fix_seoworks_mapping\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "Request" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"Request\\" does not exist", detail: None, hint: None, position: None, where_: Some("SQL statement \\"ALTER TABLE \\"SEOWorksTaskMapping\\" ADD CONSTRAINT \\"SEOWorksTaskMapping_requestId_fkey\\" \\n        FOREIGN KEY (\\"requestId\\") REFERENCES \\"Request\\"(\\"id\\") ON DELETE CASCADE ON UPDATE CASCADE\\"\\nPL/pgSQL function inline_code_block line 8 at SQL statement"), schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250108_fix_seoworks_mapping"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250108_fix_seoworks_mapping"\n             at schema-engine/commands/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-07-28 18:57:58.76542+00	2025-07-28 18:57:27.486315+00	0
005a8d36-37fd-41c9-a038-939a620b51a9	2057a17ccab02e86e8ec55ad61f4c2ac49ae43c6cf9403bd9ae2c11cc531d61b	2025-07-25 21:54:11.169118+00	20250125_add_dealership_properties	\N	\N	2025-07-25 21:54:11.020621+00	1
47695023-2c6c-4115-b4fd-4b0275c9a611	c5b9c4afbb60377dfdbabc35659f63ad9f88d532829d26f2e09dcb1effdd5b09	2025-07-28 18:57:58.9178+00	20250108_fix_seoworks_mapping		\N	2025-07-28 18:57:58.9178+00	0
ac1f8e96-48a0-4602-b10e-31eead64f9be	4ce43d2a8f4d1dd906b897d1313ca4e45e8ae22acdb3deb5593fa22956d00d68	\N	20250103_add_seoworks_mapping	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250103_add_seoworks_mapping\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "Request" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"Request\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250103_add_seoworks_mapping"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250103_add_seoworks_mapping"\n             at schema-engine/commands/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-07-28 18:57:16.69374+00	2025-07-28 18:54:55.931331+00	0
75c695e4-ff27-48f9-8b9c-0b2e61c1c791	5ac15b1d9ebfcc08dc171683765a886e8cec10102f6d35ee02646a46f8756f05	2025-07-28 18:57:16.84991+00	20250103_add_seoworks_mapping		\N	2025-07-28 18:57:16.84991+00	0
ac92c324-f033-4850-91b0-cb14934e70e6	c2799dd3240bec4a0dbdd0e57b325e754bbdea2d53f02a12694321f31d5c795d	2025-07-30 17:46:51.912251+00	20250710_add_invitation_tokens	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250710_add_invitation_tokens\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "User" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"User\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250710_add_invitation_tokens"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250710_add_invitation_tokens"\n             at schema-engine/commands/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	\N	2025-07-29 14:57:42.790911+00	0
add_orphaned_tasks_1754110320.954101	0811b026e41f965be2387f7c549254e5	2025-08-02 04:52:00.954101+00	20250202_add_orphaned_tasks_table	\N	\N	2025-08-02 04:52:00.954101+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.accounts (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
8745683c-29ec-469b-a913-f33f733a825c	4eea201b-661e-4fba-a982-f28161b90444	invitation	invitation	4eea201b-661e-4fba-a982-f28161b90444	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: agencies; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.agencies (id, name, slug, domain, "primaryColor", "secondaryColor", logo, plan, status, "maxUsers", "maxConversations", "createdAt", "updatedAt", "ga4PropertyId", "ga4PropertyName", "ga4RefreshToken") FROM stdin;
agency-seoworks	SEOWORKS	seoworks	\N	#3b82f6	#1e40af	\N	starter	active	5	100	2025-07-21 20:53:49.954	2025-07-28 00:51:52.384	\N	\N	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.audit_logs (id, action, "entityType", "entityId", "userEmail", "userId", details, resource, "createdAt") FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.conversations (id, title, model, "agencyId", "userId", "messageCount", "lastMessage", "lastMessageAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: dealership_onboardings; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.dealership_onboardings (id, "agencyId", "businessName", package, "mainBrand", "otherBrand", address, city, state, "zipCode", "contactName", "contactTitle", email, phone, "websiteUrl", "billingEmail", "siteAccessNotes", "targetVehicleModels", "targetCities", "targetDealers", "submittedBy", status, "seoworksResponse", "submittedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: dealerships; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.dealerships (id, name, "agencyId", website, address, phone, "activePackageType", "currentBillingPeriodStart", "currentBillingPeriodEnd", "pagesUsedThisPeriod", "blogsUsedThisPeriod", "gbpPostsUsedThisPeriod", "improvementsUsedThisPeriod", settings, "createdAt", "updatedAt", "clientId", "ga4PropertyId", "searchConsoleSiteUrl") FROM stdin;
dealer-winnebago-rockford	Winnebago of Rockford	agency-seoworks	https://www.winnebagomotorhomes.com/	\N	\N	\N	\N	\N	0	0	0	0	\N	2025-07-21 20:53:53.085	2025-07-28 01:10:43.222	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-genesis-wichita	Genesis of Wichita	agency-seoworks	https://www.genesisofwichita.com/	\N	\N	PLATINUM	2025-07-31 01:17:08.486	2025-08-30 01:17:08.486	0	0	0	0	\N	2025-07-21 20:53:51.636	2025-07-31 01:17:08.487	dealer-genesis-wichita	317592148	https://www.jayhatfieldhondawichita.com/
dealer-aeo-powersports	AEO Powersports	agency-seoworks	https://aeopowersports.com/	\N	\N	PLATINUM	2025-07-31 01:17:08.301	2025-08-30 01:17:08.301	0	0	0	0	\N	2025-07-21 20:53:52.795	2025-07-31 01:17:08.303	\N	317592148	https://aeopowersports.com/
dealer-columbus-auto-group	Columbus Auto Group	agency-seoworks	https://columbusautogroup.com/	\N	\N	SILVER	2025-07-31 01:17:08.424	2025-08-30 01:17:08.424	0	0	0	0	\N	2025-07-21 20:53:52.938	2025-07-31 01:17:08.425	\N	317592148	https://columbusautogroup.com/
dealer-hatchett-hyundai-east	Hatchett Hyundai East	agency-seoworks	https://www.hatchetthyundaieast.com/	\N	\N	SILVER	2025-07-31 01:17:08.547	2025-08-30 01:17:08.547	0	0	0	0	\N	2025-07-21 20:53:52.069	2025-07-31 01:17:08.548	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-hatchett-hyundai-west	Hatchett Hyundai West	agency-seoworks	https://www.hatchetthyundaiwest.com/	\N	\N	SILVER	2025-07-31 01:17:08.608	2025-08-30 01:17:08.608	0	0	0	0	\N	2025-07-21 20:53:52.213	2025-07-31 01:17:08.609	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhc-columbus	Jay Hatfield Chevrolet of Columbus	agency-seoworks	https://www.jayhatfieldchevy.net/	\N	\N	SILVER	2025-07-31 01:17:08.668	2025-08-30 01:17:08.668	0	0	0	0	\N	2025-07-21 20:53:50.012	2025-07-31 01:17:08.669	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhc-chanute	Jay Hatfield Chevrolet GMC of Chanute	agency-seoworks	https://www.jayhatfieldchanute.com/	\N	\N	SILVER	2025-07-31 01:17:08.728	2025-08-30 01:17:08.728	0	0	0	0	\N	2025-07-21 20:53:50.185	2025-07-31 01:17:08.729	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhc-pittsburg	Jay Hatfield Chevrolet GMC of Pittsburg	agency-seoworks	https://www.jayhatfieldchevroletgmc.com/	\N	\N	SILVER	2025-07-31 01:17:08.79	2025-08-30 01:17:08.79	0	0	0	0	\N	2025-07-21 20:53:50.331	2025-07-31 01:17:08.791	\N	320759942	https://www.jayhatfieldottawa.com/
dealer-jhc-vinita	Jay Hatfield Chevrolet of Vinita	agency-seoworks	https://www.jayhatfieldchevroletvinita.com/	\N	\N	SILVER	2025-07-31 01:17:08.85	2025-08-30 01:17:08.85	0	0	0	0	\N	2025-07-21 20:53:50.477	2025-07-31 01:17:08.851	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhm-frontenac	Jay Hatfield Motorsports of Frontenac	agency-seoworks	https://www.jayhatfieldkawasaki.com/	\N	\N	SILVER	2025-07-31 01:17:08.998	2025-08-30 01:17:08.999	0	0	0	0	\N	2025-07-21 20:53:51.203	2025-07-31 01:17:08.999	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhm-joplin	Jay Hatfield Motorsports of Joplin	agency-seoworks	https://www.jhmofjoplin.com/	\N	\N	SILVER	2025-07-31 01:17:09.059	2025-08-30 01:17:09.059	0	0	0	0	\N	2025-07-21 20:53:51.347	2025-07-31 01:17:09.06	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhm-wichita	Jay Hatfield Motorsports of Wichita	agency-seoworks	https://www.kansasmotorsports.com/	\N	\N	SILVER	2025-07-31 01:17:09.169	2025-08-30 01:17:09.169	0	0	0	0	\N	2025-07-21 20:53:51.056	2025-07-31 01:17:09.17	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-premier-auto-tucson	Premier Auto Center - Tucson	agency-seoworks	https://scottsaysyes.com/	\N	\N	SILVER	2025-07-31 01:17:09.239	2025-08-30 01:17:09.239	0	0	0	0	\N	2025-07-21 20:53:52.502	2025-07-31 01:17:09.24	\N	317592148	https://premiermitsubishi.com/
dealer-premier-mitsubishi	Premier Mitsubishi	agency-seoworks	https://premiermitsubishi.com/	\N	\N	SILVER	2025-07-31 01:17:09.299	2025-08-30 01:17:09.299	0	0	0	0	\N	2025-07-21 20:53:52.357	2025-07-31 01:17:09.3	\N	317592148	https://premiermitsubishi.com/
dealer-sarcoxie-ford	Sarcoxie Ford	agency-seoworks	https://www.sarcoxieford.com	\N	\N	SILVER	2025-07-31 01:17:09.36	2025-08-30 01:17:09.36	0	0	0	0	\N	2025-07-21 20:53:50.767	2025-07-31 01:17:09.361	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-acura-columbus	Acura of Columbus	agency-seoworks	https://www.acuracolumbus.com/	\N	\N	SILVER	2025-07-31 01:27:53.138	2025-08-30 01:27:53.138	0	0	0	0	\N	2025-07-21 20:53:51.492	2025-07-31 01:27:53.139	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhdjr-frontenac	Jay Hatfield CDJR of Frontenac	agency-seoworks	https://www.jayhatfieldchryslerdodgejeepram.com/	\N	\N	SILVER	2025-07-31 01:27:53.227	2025-08-30 01:27:53.227	0	0	0	0	\N	2025-07-21 20:53:50.622	2025-07-31 01:27:53.228	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhhp-wichita	Jay Hatfield Honda Powerhouse	agency-seoworks	https://www.jayhatfieldhondawichita.com/	\N	\N	SILVER	2025-07-31 01:27:53.286	2025-08-30 01:27:53.286	0	0	0	0	\N	2025-07-21 20:53:50.912	2025-07-31 01:27:53.287	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhm-portal	Jay Hatfield Motorsports Portal	agency-seoworks	http://jayhatfieldmotorsports.com/	\N	\N	PLATINUM	2025-07-31 01:27:53.346	2025-08-30 01:27:53.346	0	0	0	0	\N	2025-07-21 20:53:51.781	2025-07-31 01:27:53.347	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-jhm-ottawa	Jay Hatfield Motorsports Ottawa	agency-seoworks	https://www.jayhatfieldottawa.com/	\N	\N	SILVER	2025-07-31 01:27:53.408	2025-08-30 01:27:53.408	0	0	0	0	\N	2025-07-21 20:53:51.925	2025-07-31 01:27:53.409	\N	317592148	https://www.jayhatfieldhondawichita.com/
dealer-world-kia	World Kia	agency-seoworks	https://www.worldkiajoliet.com/	\N	\N	PLATINUM	2025-07-31 01:27:53.469	2025-08-30 01:27:53.469	0	0	0	0	\N	2025-07-21 20:53:52.646	2025-07-31 01:27:53.47	\N	317592148	https://www.jayhatfieldhondawichita.com/
\.


--
-- Data for Name: escalations; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.escalations (id, "agencyId", "userId", "userEmail", "conversationId", subject, description, priority, category, "chatContext", status, "assignedTo", "assignedAt", resolution, "resolvedBy", "resolvedAt", "internalNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: feature_flag_overrides; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.feature_flag_overrides (id, "agencyId", "flagKey", enabled, "rolloutPercentage", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ga4_connections; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.ga4_connections (id, "userId", "dealershipId", "accessToken", "refreshToken", "expiresAt", "propertyId", "propertyName", "createdAt", "updatedAt") FROM stdin;
cmdsymufh0001nm2ionch4qdn	f0f77fa5-e611-47f0-807a-134b54b99bad	\N	99f51b787b3e0b9c9e9527ee01dcb74c:ce32314ea015390779ddb59832c31866:e3539a719c9ff8d61efd4715ed9c47054a7612370b9f10f87674256c662bc1115811ff893da00402a52106e8befee57ce7249011299cf3d07b27a3fe4d46f81e7c087851cbe19aaee320efab1ace2ce30e5a3458c64f5b56ff899e8abe326b4181f9861f864360b8459ba6e0f4ad49949469d583b3d4493cd8c3b1d7a61ca85eb4134b81868014e1571a528818c182b4366fd2396cf59e43b9ad95714b7d166afffee2419a94a0a2869d66355594a740ed19b82f26a3036c18f1cad921a97116b1bd0ce2e5d5be05b520e00e833777f43ae9bc1313f6a0b8f970e1a9fd3c	2928bd3e9ad8caa95cd89ba85be117a8:ed3472ae3275e61cd2f0e0178517d0cd:c4c1923af7ade2af391f161e140defe250c4f4117f4d813225f79816573f9d2ce0ec6c038adc05390ce2b6161bb611e601e88c7520f0cabc6d63f6cbbfd5fafe45d0e249b2a3fec75b0b99a2fcaf3ae36a565a669aafa7426a570ad440740427eb43669813493a	2025-08-01 20:39:49.565	320759942	Jay Hatfield Chevrolet	2025-08-01 15:10:06.221	2025-08-01 19:39:50.566
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.messages (id, content, role, model, "agencyId", "conversationId", "userId", "tokenCount", "responseTime", "createdAt") FROM stdin;
\.


--
-- Data for Name: monthly_usage; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.monthly_usage (id, "userId", "dealershipId", month, year, "packageType", "pagesUsed", "blogsUsed", "gbpPostsUsed", "improvementsUsed", "archivedAt") FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.orders (id, "agencyId", "userEmail", "taskType", title, description, status, "assignedTo", "estimatedHours", "actualHours", deliverables, "completionNotes", "qualityScore", "createdAt", "updatedAt", "completedAt", "seoworksTaskId") FROM stdin;
\.


--
-- Data for Name: orphaned_tasks; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.orphaned_tasks (id, "clientId", "clientEmail", "taskType", "externalId", status, "completionDate", deliverables, "rawPayload", processed, "processedAt", "createdAt", "updatedAt", "eventType", "linkedRequestId", notes) FROM stdin;
\.


--
-- Data for Name: report_schedules; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.report_schedules (id, "agencyId", "cronPattern", "ga4PropertyId", "userId", "reportType", "emailRecipients", "brandingOptionsJson", "isActive", "lastRun", "nextRun", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.requests (id, "userId", "agencyId", title, description, type, priority, status, "packageType", "pagesCompleted", "blogsCompleted", "gbpPostsCompleted", "improvementsCompleted", keywords, "targetUrl", "targetCities", "targetModels", "completedTasks", "contentUrl", "pageTitle", "completedAt", "createdAt", "updatedAt", "dealershipId", "seoworksTaskId") FROM stdin;
1480881e-867b-4841-9de6-9ca7f25721c1	4eea201b-661e-4fba-a982-f28161b90444	agency-seoworks	Local Landing Pages Creation	Create dedicated landing pages for key service areas with local SEO optimization and targeted content.	page	MEDIUM	COMPLETED	PLATINUM	6	4	12	3	["honda dealer wichita", "new honda cars kansas", "honda service wichita"]	https://www.jayhatfieldhonda.com/wichita	["Wichita", "Topeka", "Lawrence"]	["Honda Civic", "Honda Accord", "Honda CR-V"]	\N	\N	\N	2025-07-21 00:53:49.835	2025-07-14 04:16:21.417	2025-07-28 00:53:51.078	dealer-jhm-portal	\N
test-request-webhook-1753892478282	4eea201b-661e-4fba-a982-f28161b90444	\N	Test Blog Request for Webhook	This is a test request to verify webhook functionality	blog	MEDIUM	COMPLETED	\N	0	1	0	0	\N	\N	\N	\N	[{"url": "https://acuracolumbus.com/blog/test-winter-maintenance", "type": "blog", "title": "Test Blog Post - Winter Maintenance Tips for Acura", "completedAt": "2025-07-30T16:21:37.673Z"}]	\N	\N	2025-07-30 16:21:37.921	2025-07-30 16:21:18.284	2025-07-30 16:21:37.928	\N	\N
40c73a0d-a5d3-4f15-bd8a-147bca748477	4eea201b-661e-4fba-a982-f28161b90444	agency-seoworks	Seasonal Promotion Campaign	Holiday promotion landing page with targeted content for end-of-year vehicle sales and special financing offers.	page	HIGH	IN_PROGRESS	PLATINUM	1	1	4	0	["holiday car deals", "year end auto sales", "december car specials"]	https://www.jayhatfieldmotorsports.com/specials	["Columbus", "Wichita", "Frontenac"]	["Chevrolet Tahoe", "GMC Acadia", "Buick Enclave"]	\N	\N	\N	\N	2025-07-03 07:44:51.816	2025-07-28 00:53:51.382	dealer-jhdjr-frontenac	\N
\.


--
-- Data for Name: search_console_connections; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.search_console_connections (id, "userId", "dealershipId", "accessToken", "refreshToken", "expiresAt", "siteUrl", "siteName", "createdAt", "updatedAt") FROM stdin;
cmds7r97c0003n92jv44h1h7h	f0f77fa5-e611-47f0-807a-134b54b99bad	\N	fba63d68d579f40b3e9c19b232ec45d1:d8118e9237877f65d675163060ec3a5e:0c939a085f36afa2b3044e4096b3bec193df8d78cb641caedf1fc6d5d892bf97fb1318434835e992cc1898b788f791b8caf3c23e67c0a4ecc67a13c73997a9b66ea8f5dca3403ed61d0ebafe030a499e9955eb0bee935b088ac171571c2dd3be5f4ef4582dd8f2e0bae64955c63e392cf543a1de3cb33afd22683ae8e6020642156d2de20d9a46914435cce2882ed50147dd6f3de3cd577f8f36f0eee1b022051d68968cac4d43fc0bbf6a2533f5ce7dfd9c0f1f338a93ec24c849663db20ab717ab7de790d13f43918a96948e922c1e571b5a11755e6eae13832c5facb9	02c78c83e58040e343d76d38a1c7a686:74d2a722b9d648dca01f989ed8969a71:12a2e3d23720699c3db2e5558b90568dbeeff3c708f3acde6941c83c5fbc909e35f79a4b2a786eed7295b797b5fd8e280c0a5484e71192e9e52a92e7d77566f6d551dab533d7fad03c1618a28423c40795248929d76980a418de88e961190044fc435ed086ce81	2025-08-01 03:37:41.035	https://www.worldkiajoliet.com/	www.worldkiajoliet.com	2025-08-01 02:37:42.361	2025-08-01 02:37:42.361
cmds9s8i60003mv2jsswfmce7	4eea201b-661e-4fba-a982-f28161b90444	dealer-jhdjr-frontenac	e1685870a0a387ae4765efe64d03a4d2:6a951a5d2f63468c7dbf1dad0d3b3fb8:7660970bc068ad745e62563e4780b1db0f19b16963c0ba6365d0b0959cb3861ddbbc9e22f00533133b67d53721f19746049ed771a8b52f699984b52bb192ed65c63fd56b0f47944c5167fbd717f06b8d47102d085c21031c92d010008488e0e65c5ec7067e43c33f4392958a67876d4cf60fd75145b96706fb9cde8a679c639c668365418d39500a4501bd3300ff9546752758d692bfab2f4acdd6f6e64bc24bf13f094aa279caabf2e645d0d55645952267e2f90e45cd387cfb439f6f71ab1aa779c56a9861e4873e8491da721a73130beb0a8af7d5565efbe1cbb07f4f	279bd75487e13e45ed1112994fa9860a:c2b5724e31a073c1931730745e6a964e:2e8a7630186ffa64dbef19bb7f79f8639070ab6e1e7392fee5a71c0fa327d86966fc2fd7fa0d91eafb0c745ac67d63f829653b145f466299511c7f6809eb38ec1bc6a3500a9360249f1ddf162c5b56cfc6ecade395e3b231c8d5af23b34b88be4edb39acce8530	2025-08-01 04:45:40.247	https://genesisofwichita.com/	genesisofwichita.com	2025-08-01 03:34:27.342	2025-08-01 03:45:41.578
\.


--
-- Data for Name: seoworks_task_mappings; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.seoworks_task_mappings (id, "requestId", "seoworksTaskId", "taskType", metadata, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: seoworks_tasks; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.seoworks_tasks (id, "externalId", "taskType", status, "completionDate", "postTitle", "postUrl", "completionNotes", "isWeekly", payload, "orderId", "agencyId", "receivedAt", "processedAt") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.sessions (id, "sessionToken", "userId", expires) FROM stdin;
cmddlbio00003n93phemwqha1	07b58aa6f5bcf66af09d089485e0ad1e5571b9ea4e79fecb55d6710e758a2005	4eea201b-661e-4fba-a982-f28161b90444	2025-08-20 21:00:50.082
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.system_settings (id, "maintenanceMode", "newUserRegistration", "emailNotifications", "auditLogging", "maxUsersPerAgency", "maxRequestsPerUser", "maxFileUploadSize", "smtpHost", "smtpPort", "smtpUser", "smtpFromEmail", "maintenanceMessage", "welcomeMessage", "rateLimitPerMinute", "sessionTimeoutMinutes", "createdAt", "updatedAt") FROM stdin;
default	f	t	t	t	50	1000	10		587			The system is currently under maintenance.Please try again later.	Welcome to our SEO management platform! Get started by exploring your dashboard.	60	480	2025-07-21 00:45:55.256	2025-07-21 00:45:55.256
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.tasks (id, "userId", "dealershipId", "agencyId", type, status, title, description, priority, "targetUrl", keywords, "requestId", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: themes; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.themes (id, "agencyId", "companyName", "primaryColor", "secondaryColor", logo, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: usage_metrics; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.usage_metrics (id, "agencyId", "metricType", value, model, date, period) FROM stdin;
\.


--
-- Data for Name: user_ga4_tokens; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.user_ga4_tokens (id, "userId", "encryptedAccessToken", "encryptedRefreshToken", "expiryDate", scope, "tokenType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_invites; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.user_invites (id, email, role, "isSuperAdmin", "agencyId", "invitedBy", token, status, "acceptedAt", "expiresAt", "createdAt", "updatedAt") FROM stdin;
c401da9d-e0b2-420d-aa5f-0b58156e5b8d	josh.copp@onekeel.ai	SUPER_ADMIN	t	\N	f0f77fa5-e611-47f0-807a-134b54b99bad	80167aefe0fe783f71a0d341194c55e576fd58062589060150976ab594a48883	pending	\N	2025-07-31 15:16:45.361	2025-07-30 15:16:45.361	2025-07-30 15:16:45.361
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.user_preferences (id, "userId", "emailNotifications", "requestCreated", "statusChanged", "taskCompleted", "weeklySummary", "marketingEmails", timezone, language, "createdAt", "updatedAt") FROM stdin;
cmdcdx35z0001pe392fw01sq3	f0f77fa5-e611-47f0-807a-134b54b99bad	t	t	t	t	t	f	America/Chicago	en	2025-07-21 00:45:53.351	2025-07-21 00:45:53.351
cmddlb6gx0001n93pxrag0lj7	4eea201b-661e-4fba-a982-f28161b90444	t	t	t	t	t	f	America/New_York	en	2025-07-21 21:00:34.306	2025-07-21 21:00:34.306
\.


--
-- Data for Name: user_search_console_tokens; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.user_search_console_tokens (id, "userId", "encryptedAccessToken", "encryptedRefreshToken", "expiryDate", scope, "verifiedSites", "primarySite", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.users (id, name, email, "emailVerified", image, "agencyId", "dealershipId", role, theme, "createdAt", "updatedAt", "isSuperAdmin", "onboardingCompleted", "invitationToken", "invitationTokenExpires", "apiKey", "apiKeyCreatedAt", password) FROM stdin;
a3fed1f8-e8e2-4810-8d94-0e8c88526393	rylie	rylie1234@gmail.com	\N	\N	agency-seoworks	\N	USER	\N	2025-08-01 04:49:19.786	2025-08-01 20:18:21.202	f	f	d0818611c34a93afe504307d727e2c320969062bf50449ab9f22a9c30b21e715	2025-08-08 20:18:21.202	\N	\N	\N
f0f77fa5-e611-47f0-807a-134b54b99bad	Josh Copp	josh.copp@onekeel.ai	\N	\N	\N	\N	SUPER_ADMIN	\N	2025-07-21 00:45:51.626	2025-07-30 15:41:42.815	t	f	\N	\N	\N	\N	$2a$10$lXSvJ..Gef8QamyroCN7KOvW7lQAsld.3FmlLd1E8D7hSDztqJtPy
4eea201b-661e-4fba-a982-f28161b90444	access	access@seowerks.ai	2025-07-21 21:00:49.775	\N	agency-seoworks	dealer-acura-columbus	AGENCY_ADMIN	\N	2025-07-21 21:00:34.127	2025-08-01 14:26:24.374	f	t	ecd6b0d950008d1842b178b6933cb9f911b43a6f1674cf21c70634f535ed6d64	2025-07-28 21:12:42.364	\N	\N	$2a$10$lXSvJ..Gef8QamyroCN7KOvW7lQAsld.3FmlLd1E8D7hSDztqJtPy
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: rylie_user
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: agencies agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: dealership_onboardings dealership_onboardings_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.dealership_onboardings
    ADD CONSTRAINT dealership_onboardings_pkey PRIMARY KEY (id);


--
-- Name: dealerships dealerships_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.dealerships
    ADD CONSTRAINT dealerships_pkey PRIMARY KEY (id);


--
-- Name: escalations escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT escalations_pkey PRIMARY KEY (id);


--
-- Name: feature_flag_overrides feature_flag_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.feature_flag_overrides
    ADD CONSTRAINT feature_flag_overrides_pkey PRIMARY KEY (id);


--
-- Name: ga4_connections ga4_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.ga4_connections
    ADD CONSTRAINT ga4_connections_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: monthly_usage monthly_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.monthly_usage
    ADD CONSTRAINT monthly_usage_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orphaned_tasks orphaned_tasks_externalId_key; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.orphaned_tasks
    ADD CONSTRAINT "orphaned_tasks_externalId_key" UNIQUE ("externalId");


--
-- Name: orphaned_tasks orphaned_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.orphaned_tasks
    ADD CONSTRAINT orphaned_tasks_pkey PRIMARY KEY (id);


--
-- Name: report_schedules report_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: search_console_connections search_console_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.search_console_connections
    ADD CONSTRAINT search_console_connections_pkey PRIMARY KEY (id);


--
-- Name: seoworks_task_mappings seoworks_task_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.seoworks_task_mappings
    ADD CONSTRAINT seoworks_task_mappings_pkey PRIMARY KEY (id);


--
-- Name: seoworks_tasks seoworks_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.seoworks_tasks
    ADD CONSTRAINT seoworks_tasks_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: themes themes_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.themes
    ADD CONSTRAINT themes_pkey PRIMARY KEY (id);


--
-- Name: usage_metrics usage_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.usage_metrics
    ADD CONSTRAINT usage_metrics_pkey PRIMARY KEY (id);


--
-- Name: user_ga4_tokens user_ga4_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_ga4_tokens
    ADD CONSTRAINT user_ga4_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_invites user_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_search_console_tokens user_search_console_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_search_console_tokens
    ADD CONSTRAINT user_search_console_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- Name: agencies_domain_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX agencies_domain_key ON public.agencies USING btree (domain);


--
-- Name: agencies_slug_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX agencies_slug_key ON public.agencies USING btree (slug);


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_userEmail_createdAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "audit_logs_userEmail_createdAt_idx" ON public.audit_logs USING btree ("userEmail", "createdAt");


--
-- Name: conversations_agencyId_updatedAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "conversations_agencyId_updatedAt_idx" ON public.conversations USING btree ("agencyId", "updatedAt");


--
-- Name: conversations_agencyId_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "conversations_agencyId_userId_idx" ON public.conversations USING btree ("agencyId", "userId");


--
-- Name: dealership_onboardings_agencyId_createdAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "dealership_onboardings_agencyId_createdAt_idx" ON public.dealership_onboardings USING btree ("agencyId", "createdAt");


--
-- Name: dealership_onboardings_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "dealership_onboardings_agencyId_status_idx" ON public.dealership_onboardings USING btree ("agencyId", status);


--
-- Name: dealerships_agencyId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "dealerships_agencyId_idx" ON public.dealerships USING btree ("agencyId");


--
-- Name: dealerships_clientId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "dealerships_clientId_key" ON public.dealerships USING btree ("clientId");


--
-- Name: escalations_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "escalations_agencyId_status_idx" ON public.escalations USING btree ("agencyId", status);


--
-- Name: escalations_assignedTo_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "escalations_assignedTo_status_idx" ON public.escalations USING btree ("assignedTo", status);


--
-- Name: escalations_conversationId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "escalations_conversationId_idx" ON public.escalations USING btree ("conversationId");


--
-- Name: escalations_userId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "escalations_userId_status_idx" ON public.escalations USING btree ("userId", status);


--
-- Name: feature_flag_overrides_agencyId_flagKey_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "feature_flag_overrides_agencyId_flagKey_key" ON public.feature_flag_overrides USING btree ("agencyId", "flagKey");


--
-- Name: ga4_connections_dealershipId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "ga4_connections_dealershipId_idx" ON public.ga4_connections USING btree ("dealershipId");


--
-- Name: ga4_connections_userId_dealershipId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "ga4_connections_userId_dealershipId_key" ON public.ga4_connections USING btree ("userId", "dealershipId");


--
-- Name: ga4_connections_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "ga4_connections_userId_idx" ON public.ga4_connections USING btree ("userId");


--
-- Name: messages_agencyId_conversationId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "messages_agencyId_conversationId_idx" ON public.messages USING btree ("agencyId", "conversationId");


--
-- Name: messages_agencyId_createdAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "messages_agencyId_createdAt_idx" ON public.messages USING btree ("agencyId", "createdAt");


--
-- Name: monthly_usage_dealershipId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "monthly_usage_dealershipId_idx" ON public.monthly_usage USING btree ("dealershipId");


--
-- Name: monthly_usage_dealershipId_month_year_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "monthly_usage_dealershipId_month_year_key" ON public.monthly_usage USING btree ("dealershipId", month, year);


--
-- Name: monthly_usage_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "monthly_usage_userId_idx" ON public.monthly_usage USING btree ("userId");


--
-- Name: monthly_usage_userId_month_year_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "monthly_usage_userId_month_year_key" ON public.monthly_usage USING btree ("userId", month, year);


--
-- Name: orders_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "orders_agencyId_status_idx" ON public.orders USING btree ("agencyId", status);


--
-- Name: orders_userEmail_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "orders_userEmail_status_idx" ON public.orders USING btree ("userEmail", status);


--
-- Name: orphaned_tasks_clientEmail_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "orphaned_tasks_clientEmail_idx" ON public.orphaned_tasks USING btree ("clientEmail");


--
-- Name: orphaned_tasks_clientId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "orphaned_tasks_clientId_idx" ON public.orphaned_tasks USING btree ("clientId");


--
-- Name: orphaned_tasks_externalId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "orphaned_tasks_externalId_idx" ON public.orphaned_tasks USING btree ("externalId");


--
-- Name: orphaned_tasks_processed_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX orphaned_tasks_processed_idx ON public.orphaned_tasks USING btree (processed);


--
-- Name: report_schedules_agencyId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "report_schedules_agencyId_idx" ON public.report_schedules USING btree ("agencyId");


--
-- Name: report_schedules_isActive_nextRun_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "report_schedules_isActive_nextRun_idx" ON public.report_schedules USING btree ("isActive", "nextRun");


--
-- Name: report_schedules_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "report_schedules_userId_idx" ON public.report_schedules USING btree ("userId");


--
-- Name: requests_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "requests_agencyId_status_idx" ON public.requests USING btree ("agencyId", status);


--
-- Name: requests_status_createdAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "requests_status_createdAt_idx" ON public.requests USING btree (status, "createdAt");


--
-- Name: requests_userId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "requests_userId_status_idx" ON public.requests USING btree ("userId", status);


--
-- Name: search_console_connections_dealershipId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "search_console_connections_dealershipId_idx" ON public.search_console_connections USING btree ("dealershipId");


--
-- Name: search_console_connections_userId_dealershipId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "search_console_connections_userId_dealershipId_key" ON public.search_console_connections USING btree ("userId", "dealershipId");


--
-- Name: search_console_connections_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "search_console_connections_userId_idx" ON public.search_console_connections USING btree ("userId");


--
-- Name: seoworks_task_mappings_requestId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "seoworks_task_mappings_requestId_idx" ON public.seoworks_task_mappings USING btree ("requestId");


--
-- Name: seoworks_task_mappings_seoworksTaskId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "seoworks_task_mappings_seoworksTaskId_idx" ON public.seoworks_task_mappings USING btree ("seoworksTaskId");


--
-- Name: seoworks_task_mappings_seoworksTaskId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "seoworks_task_mappings_seoworksTaskId_key" ON public.seoworks_task_mappings USING btree ("seoworksTaskId");


--
-- Name: seoworks_tasks_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "seoworks_tasks_agencyId_status_idx" ON public.seoworks_tasks USING btree ("agencyId", status);


--
-- Name: seoworks_tasks_externalId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "seoworks_tasks_externalId_idx" ON public.seoworks_tasks USING btree ("externalId");


--
-- Name: seoworks_tasks_externalId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "seoworks_tasks_externalId_key" ON public.seoworks_tasks USING btree ("externalId");


--
-- Name: seoworks_tasks_orderId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "seoworks_tasks_orderId_key" ON public.seoworks_tasks USING btree ("orderId");


--
-- Name: seoworks_tasks_taskType_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "seoworks_tasks_taskType_status_idx" ON public.seoworks_tasks USING btree ("taskType", status);


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: tasks_agencyId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "tasks_agencyId_status_idx" ON public.tasks USING btree ("agencyId", status);


--
-- Name: tasks_status_createdAt_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "tasks_status_createdAt_idx" ON public.tasks USING btree (status, "createdAt");


--
-- Name: tasks_userId_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "tasks_userId_status_idx" ON public.tasks USING btree ("userId", status);


--
-- Name: themes_agencyId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "themes_agencyId_key" ON public.themes USING btree ("agencyId");


--
-- Name: usage_metrics_agencyId_date_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "usage_metrics_agencyId_date_idx" ON public.usage_metrics USING btree ("agencyId", date);


--
-- Name: usage_metrics_agencyId_metricType_date_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "usage_metrics_agencyId_metricType_date_idx" ON public.usage_metrics USING btree ("agencyId", "metricType", date);


--
-- Name: user_ga4_tokens_userId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "user_ga4_tokens_userId_key" ON public.user_ga4_tokens USING btree ("userId");


--
-- Name: user_invites_email_agencyId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "user_invites_email_agencyId_key" ON public.user_invites USING btree (email, "agencyId");


--
-- Name: user_invites_email_status_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX user_invites_email_status_idx ON public.user_invites USING btree (email, status);


--
-- Name: user_invites_token_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX user_invites_token_idx ON public.user_invites USING btree (token);


--
-- Name: user_invites_token_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX user_invites_token_key ON public.user_invites USING btree (token);


--
-- Name: user_preferences_userId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "user_preferences_userId_idx" ON public.user_preferences USING btree ("userId");


--
-- Name: user_preferences_userId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "user_preferences_userId_key" ON public.user_preferences USING btree ("userId");


--
-- Name: user_search_console_tokens_userId_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX "user_search_console_tokens_userId_key" ON public.user_search_console_tokens USING btree ("userId");


--
-- Name: users_dealershipId_idx; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE INDEX "users_dealershipId_idx" ON public.users USING btree ("dealershipId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: rylie_user
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_userEmail_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userEmail_fkey" FOREIGN KEY ("userEmail") REFERENCES public.users(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT "conversations_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT "conversations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealership_onboardings dealership_onboardings_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.dealership_onboardings
    ADD CONSTRAINT "dealership_onboardings_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dealerships dealerships_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.dealerships
    ADD CONSTRAINT "dealerships_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: escalations escalations_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT "escalations_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: escalations escalations_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT "escalations_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: escalations escalations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.escalations
    ADD CONSTRAINT "escalations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ga4_connections ga4_connections_dealershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.ga4_connections
    ADD CONSTRAINT "ga4_connections_dealershipId_fkey" FOREIGN KEY ("dealershipId") REFERENCES public.dealerships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ga4_connections ga4_connections_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.ga4_connections
    ADD CONSTRAINT "ga4_connections_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_usage monthly_usage_dealershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.monthly_usage
    ADD CONSTRAINT "monthly_usage_dealershipId_fkey" FOREIGN KEY ("dealershipId") REFERENCES public.dealerships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_usage monthly_usage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.monthly_usage
    ADD CONSTRAINT "monthly_usage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userEmail_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userEmail_fkey" FOREIGN KEY ("userEmail") REFERENCES public.users(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: report_schedules report_schedules_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: report_schedules report_schedules_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: requests requests_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT "requests_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: requests requests_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT "requests_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: search_console_connections search_console_connections_dealershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.search_console_connections
    ADD CONSTRAINT "search_console_connections_dealershipId_fkey" FOREIGN KEY ("dealershipId") REFERENCES public.dealerships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: search_console_connections search_console_connections_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.search_console_connections
    ADD CONSTRAINT "search_console_connections_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seoworks_task_mappings seoworks_task_mappings_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.seoworks_task_mappings
    ADD CONSTRAINT "seoworks_task_mappings_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seoworks_tasks seoworks_tasks_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.seoworks_tasks
    ADD CONSTRAINT "seoworks_tasks_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seoworks_tasks seoworks_tasks_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.seoworks_tasks
    ADD CONSTRAINT "seoworks_tasks_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: themes themes_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.themes
    ADD CONSTRAINT "themes_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usage_metrics usage_metrics_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.usage_metrics
    ADD CONSTRAINT "usage_metrics_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_ga4_tokens user_ga4_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_ga4_tokens
    ADD CONSTRAINT "user_ga4_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_invites user_invites_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT "user_invites_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_invites user_invites_invitedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT "user_invites_invitedBy_fkey" FOREIGN KEY ("invitedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_preferences user_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT "user_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_search_console_tokens user_search_console_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.user_search_console_tokens
    ADD CONSTRAINT "user_search_console_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_agencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_dealershipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rylie_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_dealershipId_fkey" FOREIGN KEY ("dealershipId") REFERENCES public.dealerships(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: rylie_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES TO rylie_user;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES TO rylie_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS TO rylie_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES TO rylie_user;


--
-- PostgreSQL database dump complete
--

